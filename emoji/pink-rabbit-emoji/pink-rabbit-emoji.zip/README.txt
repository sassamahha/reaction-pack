Retro Pink Rabbit Emoji Pack - sassamahha
20 custom emoji for Slack, Microsoft Teams and Discord (128x128 transparent PNG).

How to add
- Slack: workspace name > Customize workspace > Add Custom Emoji. The file name becomes the emoji name.
- Teams: open the emoji picker > Your org's emoji > Add (your admin must allow custom emoji). Desktop or web only.
- Discord: Server Settings > Emoji > Upload Emoji. You can select all files at once.

Free for personal and team chat use. Please don't resell or redistribute the files.
More odd costume stickers: https://sassamahha.me
